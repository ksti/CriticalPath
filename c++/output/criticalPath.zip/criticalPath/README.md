## 用法：

### 1、cd 到 criticalPath/out/ 目录下
### 2、输入命令./criticalPath运行

### `注`: `criticalPath` 目录下的 `resources` 文件夹下有个 `big.json` 文件，替换这个文件可以解析不同的 json 数据

### 3、输入命令./criticalPath2运行，可手动输入
